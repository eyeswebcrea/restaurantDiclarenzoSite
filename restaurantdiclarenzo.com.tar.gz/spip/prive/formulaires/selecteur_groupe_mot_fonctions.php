<?php

/***************************************************************************\
 *  SPIP, Systeme de publication pour l'internet                           *
 *                                                                         *
 *  Copyright (c) 2001-2011                                                *
 *  Arnaud Martin, Antoine Pitrou, Philippe Riviere, Emmanuel Saint-James  *
 *                                                                         *
 *  Ce programme est un logiciel libre distribue sous licence GNU/GPL.     *
 *  Pour plus de details voir le fichier COPYING.txt ou l'aide en ligne.   *
\***************************************************************************/
/*
function critere_GROUPES_MOTS_table_dist($idb,&$boucles, $crit) {
	if (isset($crit->param[0])) {
		$_table = calculer_liste($crit->param[0], array(), $boucles, $boucles[$idb]->id_parent);
		$boucles[$idb]->where[]="$_table?preg_replace('[^w]','',$_table).\"='oui'\":\"\"";
	}
}*/

?>
