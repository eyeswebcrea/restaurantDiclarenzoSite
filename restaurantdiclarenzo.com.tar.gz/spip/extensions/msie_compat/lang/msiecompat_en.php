<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'choix_explication' => '<p>This configuration improves the public site\'s compatibility with Internet Explorer. </p>
<ul>
<li><a href=\'http://jquery.khurshid.com/ifixpng.php\'>iFixPng</a> (<b>default setting</b>) restores semi-transparency of the PNG images  on MSIE&nbsp;5 and&nbsp;6. </li>
<li><a href=\'http://code.google.com/p/ie7-js/\'>IE7.js</a> corrects PNG transparency and adds CSS2 selectors for MSIE&nbsp;5 and&nbsp;6 (<a href=\'http://ie7-js.googlecode.com/svn/test/index.html\'>here is a list of compatible selectors introduced by IE7.js and IE8.js</a>).</li>
<li>IE8.js enhances IE7.js with CSS selectors for MSIE 5 to&nbsp;7.</li>
<li>IE7-squish fixes three bugs in MSIE 6 (including the double margin on floating elements), but side effects may appear. </li>
</ul>',
	'choix_non' => 'Deactive: do not add anything to my pages',
	'choix_titre' => 'Microsoft Internet Explorer Compatibily'
);

?>
