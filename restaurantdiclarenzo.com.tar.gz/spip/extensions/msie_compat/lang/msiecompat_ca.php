<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'choix_explication' => '<p>Aquesta configuraci&oacute; us permet millorar la compatibilitat del lloc p&uacute;blic amb el navegador Internet Explorer.</p>
   <ul>
   <li><a href=\'http://jquery.khurshid.com/ifixpng.php\'>iFixPng</a> (<b>per defecte</b>) restableix la semi transpar&egrave;ncia les imatges al format PNG a  MSIE&nbsp;5&nbsp;i&nbsp;6.</li>
   <li><a href=\'http://code.google.com/p/ie7-js/\'>IE7.js</a> corregeix les imatges PNG i afegeix selectors CSS2 per MSIE&nbsp;5&nbsp;i 6 (<a href=\'http://ie7-js.googlecode.com/svn/test/index.html\'>podeu consultar la llista de selectors compatibles introdu&iuml;ts per IE7.js i IE8.js</a>).</li>
   <li>IE8.js completa IE7.js enriquint els comportaments dels CSS de MSIE 5 al &nbsp;7. </li>
   <li>IE7-squish corregeix tres errors de MSIE&nbsp;6 (sobretot el doble marge dels elements flotants), per&ograve; poden apar&egrave;ixer efectes indesitjables (el webmestre ha de verificar la compatibilitat).</li>
   </ul>',
	'choix_non' => 'No activar-ho: no afegir res a les meves plantilles',
	'choix_titre' => 'Compatibilitat Microsoft Internet Explorer'
);

?>
