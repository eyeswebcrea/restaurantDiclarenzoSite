<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'choix_explication' => 'Diese Konfiguration verbessert die Kompatibilit&auml;t mit dem Webrowser Internet Explorer.</p>
   <ul>
   <li><a href=\'http://jquery.khurshid.com/ifixpng.php\'>iFixPng</a> (<b>par d&eacute;faut</b>) stellt die Semi-Transparenz von PNG Dateien in MSIE&nbsp;5&nbsp;und&nbsp;6 wieder her.</li>
   <li><a href=\'http://code.google.com/p/ie7-js/\'>IE7.js</a> korrigiert PNG-Dateien und f&uuml;gt CSS2 Selektoren f&uuml;r MSIE&nbsp;5&nbsp;und&nbsp;6 hinzu.(<a href=\'http://ie7-js.googlecode.com/svn/test/index.html\'>Liste der mit IE7.js und IE8.js eingef&uuml;hrten kompatiblen Selektoren</a>).</li>
   <li>IE8.js erg&auml;nzt IE7.js durch Verbesserung der CSS-Verhaltensweisen von MSIE 5 bis&nbsp;7. </li>
   <li>IE7-squish korrigiert drei Fehler des MSIE&nbsp;6 (speziell verdoppelte margins bei float-Elementen), unerw&uuml;nschte Nebeneffekte k&ouml;nnen jedoch nicht vollkommen ausgeschlossen werden (der Websmaster sollte die Kompatibilit&auml;t pr&uuml;fen).</li>
   </ul>',
	'choix_non' => 'Nicht aktivieren: Meinen Skeletten wird nichts hinzugef&uuml;gt.',
	'choix_titre' => 'Kompatibilit&auml;t mit dem Microsoft Internet Explorer'
);

?>
