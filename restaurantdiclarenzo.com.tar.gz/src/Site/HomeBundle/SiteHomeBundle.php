<?php

namespace Site\HomeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SiteHomeBundle extends Bundle
{
}
