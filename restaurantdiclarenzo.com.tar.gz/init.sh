app/console doctrine:mongodb:schema:create --index
